"""
run_all.py — Run the full E-Commerce Analytics pipeline.

Usage:
    python run_all.py
"""

import subprocess, sys, os

SCRIPTS = [
    "data/generate_data.py",
    "src/01_data_cleaning.py",
    "src/02_eda.py",
    "src/03_visualizations.py",
    "src/04_ml_model.py",
    "src/05_insights_report.py",
]

ROOT = os.path.dirname(os.path.abspath(__file__))

def run(script):
    path = os.path.join(ROOT, script)
    print(f"\n{'='*62}")
    print(f"  Running: {script}")
    print(f"{'='*62}")
    result = subprocess.run([sys.executable, path], text=True)
    if result.returncode != 0:
        print(f"❌ FAILED: {script}")
        sys.exit(result.returncode)
    print(f"✅ Done: {script}")

if __name__ == "__main__":
    for s in SCRIPTS:
        run(s)
    print("\n" + "="*62)
    print("  PIPELINE COMPLETE")
    print("="*62)
    print("  Visualizations → /visualizations/  (19 charts)")
    print("  Clean Data     → /data/")
    print("  Reports        → /reports/")
