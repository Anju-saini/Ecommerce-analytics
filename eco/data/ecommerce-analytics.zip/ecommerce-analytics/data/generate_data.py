"""
Generate realistic E-Commerce dataset for analytics project.
Produces 3 CSVs: customers, orders, products.
"""

import pandas as pd
import numpy as np
import os
import random
from datetime import datetime, timedelta

np.random.seed(42)
random.seed(42)

OUT = os.path.dirname(os.path.abspath(__file__))

# ── CONFIG ────────────────────────────────────────────────────────────────────
N_CUSTOMERS = 2000
N_PRODUCTS  = 150
N_ORDERS    = 8000

CATEGORIES = {
    "Electronics":   (1500, 800,  0.08),   # name, avg_price, std_mult, return_rate
    "Clothing":      (699,  300,  0.15),
    "Home & Kitchen":(999,  400,  0.07),
    "Books":         (299,  150,  0.04),
    "Sports":        (849,  350,  0.09),
    "Beauty":        (499,  200,  0.12),
    "Toys":          (599,  250,  0.11),
    "Grocery":       (199,  80,   0.03),
}

CITIES = {
    "Mumbai": "Maharashtra", "Delhi": "Delhi", "Bangalore": "Karnataka",
    "Hyderabad": "Telangana", "Chennai": "Tamil Nadu", "Pune": "Maharashtra",
    "Kolkata": "West Bengal", "Ahmedabad": "Gujarat", "Jaipur": "Rajasthan",
    "Lucknow": "Uttar Pradesh", "Surat": "Gujarat", "Chandigarh": "Punjab",
}

PAYMENT_METHODS = ["Credit Card", "Debit Card", "UPI", "Net Banking", "Wallet", "COD"]
PAYMENT_WEIGHTS = [0.25, 0.20, 0.30, 0.08, 0.10, 0.07]

def random_date(start="2022-01-01", end="2024-12-31"):
    s = datetime.strptime(start, "%Y-%m-%d")
    e = datetime.strptime(end,   "%Y-%m-%d")
    return s + timedelta(seconds=random.randint(0, int((e - s).total_seconds())))


# ── PRODUCTS ─────────────────────────────────────────────────────────────────
product_names = {
    "Electronics":   ["Smartphone", "Laptop", "Earbuds", "Smart Watch", "Tablet",
                      "Bluetooth Speaker", "Power Bank", "LED TV", "Camera", "Gaming Console"],
    "Clothing":      ["T-Shirt", "Jeans", "Kurta", "Saree", "Jacket",
                      "Formal Shirt", "Leggings", "Hoodie", "Ethnic Wear", "Track Pants"],
    "Home & Kitchen":["Mixer Grinder", "Non-Stick Pan", "Bedsheet Set", "Pillow",
                      "Air Purifier", "Water Bottle", "Pressure Cooker", "Curtains", "Lamp", "Vacuum Cleaner"],
    "Books":         ["Self Help Book", "Fiction Novel", "Textbook", "Biography",
                      "Cookbook", "Children Book", "Business Book", "Science Book", "History Book", "Comics"],
    "Sports":        ["Yoga Mat", "Dumbbells", "Cricket Bat", "Football",
                      "Badminton Racket", "Cycling Gloves", "Resistance Band", "Skipping Rope", "Running Shoes", "Gym Bag"],
    "Beauty":        ["Face Wash", "Moisturiser", "Lipstick", "Sunscreen",
                      "Hair Serum", "Foundation", "Perfume", "Body Lotion", "Eye Liner", "Face Mask"],
    "Toys":          ["LEGO Set", "Remote Car", "Doll", "Board Game",
                      "Puzzle", "Action Figure", "Soft Toy", "Clay Kit", "Card Game", "Drone"],
    "Grocery":       ["Basmati Rice", "Olive Oil", "Protein Bar", "Green Tea",
                      "Nuts Mix", "Spice Kit", "Honey", "Oats", "Dark Chocolate", "Instant Noodles"],
}

products = []
pid = 1
for cat, (avg_p, std_p, ret_r) in CATEGORIES.items():
    names = product_names[cat]
    for name in names:
        price = max(49, int(np.random.normal(avg_p, std_p * 0.4)))
        cost  = int(price * np.random.uniform(0.45, 0.70))
        products.append({
            "product_id":    f"P{pid:04d}",
            "product_name":  name,
            "category":      cat,
            "price":         price,
            "cost_price":    cost,
            "return_rate":   round(ret_r + np.random.uniform(-0.02, 0.02), 3),
            "rating":        round(np.random.uniform(3.2, 5.0), 1),
            "stock":         np.random.randint(10, 500),
        })
        pid += 1

products_df = pd.DataFrame(products)


# ── CUSTOMERS ─────────────────────────────────────────────────────────────────
cities_list = list(CITIES.keys())
first_names = ["Aarav","Aisha","Rohan","Priya","Vikas","Sneha","Rahul","Anjali","Karan","Pooja",
               "Amit","Divya","Suresh","Meera","Arjun","Neha","Raj","Simran","Siddharth","Kavya"]
last_names  = ["Sharma","Patel","Singh","Kumar","Gupta","Mehta","Joshi","Verma","Nair","Reddy"]

customers = []
for i in range(1, N_CUSTOMERS + 1):
    join_date = random_date("2021-01-01", "2023-12-31")
    city      = random.choice(cities_list)
    age       = int(np.random.normal(32, 9))
    age       = max(18, min(70, age))
    segment   = np.random.choice(
        ["Premium", "Regular", "Budget", "New"],
        p=[0.15, 0.45, 0.25, 0.15]
    )
    customers.append({
        "customer_id":    f"C{i:05d}",
        "name":           f"{random.choice(first_names)} {random.choice(last_names)}",
        "email":          f"user{i}@email.com",
        "age":            age,
        "gender":         np.random.choice(["Male", "Female", "Other"], p=[0.52, 0.46, 0.02]),
        "city":           city,
        "state":          CITIES[city],
        "segment":        segment,
        "join_date":      join_date.strftime("%Y-%m-%d"),
        "is_subscribed":  np.random.choice([1, 0], p=[0.38, 0.62]),
    })

customers_df = pd.DataFrame(customers)

# Introduce realistic missing values
customers_df.loc[np.random.choice(customers_df.index, 60), "age"]    = np.nan
customers_df.loc[np.random.choice(customers_df.index, 40), "gender"] = np.nan


# ── ORDERS ────────────────────────────────────────────────────────────────────
orders = []
oid = 1
for _ in range(N_ORDERS):
    cust    = customers_df.sample(1).iloc[0]
    prod    = products_df.sample(1).iloc[0]
    qty     = int(np.random.choice([1,2,3,4,5], p=[0.55,0.25,0.10,0.06,0.04]))
    price   = prod["price"]
    disc    = round(np.random.choice([0,0.05,0.10,0.15,0.20,0.30],
                    p=[0.30,0.20,0.20,0.15,0.10,0.05]), 2)
    revenue = round(price * qty * (1 - disc), 2)
    profit  = round((price - prod["cost_price"]) * qty * (1 - disc), 2)
    odate   = random_date("2022-01-01", "2024-12-31")
    status  = np.random.choice(
        ["Delivered", "Returned", "Cancelled", "Pending"],
        p=[0.72, 0.12, 0.10, 0.06]
    )
    # Seasonal boost: Q4 has more orders
    if odate.month in [10, 11, 12] and np.random.random() < 0.3:
        qty = min(qty + 1, 5)

    orders.append({
        "order_id":       f"O{oid:06d}",
        "customer_id":    cust["customer_id"],
        "product_id":     prod["product_id"],
        "order_date":     odate.strftime("%Y-%m-%d"),
        "quantity":       qty,
        "unit_price":     price,
        "discount":       disc,
        "revenue":        revenue,
        "profit":         profit,
        "payment_method": np.random.choice(PAYMENT_METHODS, p=PAYMENT_WEIGHTS),
        "order_status":   status,
        "delivery_days":  np.random.randint(1, 14) if status == "Delivered" else np.nan,
        "rating":         np.random.randint(1, 6) if status == "Delivered" else np.nan,
    })
    oid += 1

orders_df = pd.DataFrame(orders)

# Extra missing values in orders
orders_df.loc[np.random.choice(orders_df.index, 120), "delivery_days"] = np.nan
orders_df.loc[np.random.choice(orders_df.index, 200), "rating"]        = np.nan

# Save
customers_df.to_csv(os.path.join(OUT, "customers.csv"), index=False)
products_df.to_csv(os.path.join(OUT,  "products.csv"),  index=False)
orders_df.to_csv(os.path.join(OUT,    "orders.csv"),    index=False)

print(f"✅ customers.csv  → {len(customers_df):,} rows")
print(f"✅ products.csv   → {len(products_df):,} rows")
print(f"✅ orders.csv     → {len(orders_df):,} rows")
